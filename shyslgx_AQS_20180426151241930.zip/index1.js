(function (lib, img, cjs) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 414,
	height: 897,
	fps: 24,
	color: "#FFFFFF",
	manifest: [
		{src:"images/_02.jpg", id:"_02"},
		{src:"images/Bitmap1.png", id:"Bitmap1"},
		{src:"images/Bitmap2.png", id:"Bitmap2"},
		{src:"images/Bitmap3.png", id:"Bitmap3"},
		{src:"images/ipop_1_15_63360.png", id:"ipop_1_15_63360"},
		{src:"images/ipop_1_17_88993.png", id:"ipop_1_17_88993"},
		{src:"images/ipop_1_19_72026.png", id:"ipop_1_19_72026"},
		{src:"images/ipop_1_20_46545.png", id:"ipop_1_20_46545"},
		{src:"images/ipop_1_21_77335.png", id:"ipop_1_21_77335"},
		{src:"images/ipop_1_22_84718.jpg", id:"ipop_1_22_84718"},
		{src:"images/ipop_1_23_69253.png", id:"ipop_1_23_69253"}
	]
};



// symbols:



(lib._02 = function() {
	this.initialize(img._02);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1150,1561);


(lib.Bitmap1 = function() {
	this.initialize(img.Bitmap1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,209,65);


(lib.Bitmap2 = function() {
	this.initialize(img.Bitmap2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,140,76);


(lib.Bitmap3 = function() {
	this.initialize(img.Bitmap3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,216,76);


(lib.ipop_1_15_63360 = function() {
	this.initialize(img.ipop_1_15_63360);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1150,1561);


(lib.ipop_1_17_88993 = function() {
	this.initialize(img.ipop_1_17_88993);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,244,98);


(lib.ipop_1_19_72026 = function() {
	this.initialize(img.ipop_1_19_72026);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,584,197);


(lib.ipop_1_20_46545 = function() {
	this.initialize(img.ipop_1_20_46545);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,509,76);


(lib.ipop_1_21_77335 = function() {
	this.initialize(img.ipop_1_21_77335);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,293,33);


(lib.ipop_1_22_84718 = function() {
	this.initialize(img.ipop_1_22_84718);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,656,1167);


(lib.ipop_1_23_69253 = function() {
	this.initialize(img.ipop_1_23_69253);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,361,25);


(lib.ipop_1_12_20885 = function() {
	this.initialize();

	// 图层 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjVBlIGrAAIjQE3gAhzA6IAAiaIDkAAIAACagAh1idIAAhvIDlAAIAABvgAh1lMIAAhPIDlAAIAABPg");
	this.shape.setTransform(-6.5,-86.8);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-27.9,-128,42.8,82.5);


(lib.ipop_1_10_97962 = function() {
	this.initialize();

	// 图层 1
	this.instance = new lib.ipop_1_17_88993();
	this.instance.setTransform(-44,-4);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-44,-4,244,98);


(lib.ipop_1_9_52780 = function() {
	this.initialize();

	// 图层 1
	this.instance = new lib.Bitmap3();
	this.instance.setTransform(74.5,-12.1);

	this.instance_1 = new lib.Bitmap2();
	this.instance_1.setTransform(427.2,-12.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.ipop_1_20_46545, null, new cjs.Matrix2D(1,0,0,1,-292.3,-38)).s().p("AqrF7IAArOIhQAAIAAgnIX3AAIAAAnIhQAAIAALOg");
	this.shape.setTransform(358.8,21.9);

	this.addChild(this.shape,this.instance_1,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(74.5,-16.1,492.7,80);


(lib.ipop_1_8_24192 = function() {
	this.initialize();

	// 图层 5
	this.instance = new lib.ipop_1_21_77335();
	this.instance.setTransform(88.9,103.3);

	// 图层 6
	this.instance_1 = new lib.Bitmap1();
	this.instance_1.setTransform(222.4,89.2);

	// 图层 7
	this.instance_2 = new lib.ipop_1_23_69253();
	this.instance_2.setTransform(259.8,763.9);

	// 图层 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("EgzdAZdMAAAgy5MBm7AAAMAAAAy5g");
	this.shape.setTransform(354.8,1235.2);

	// 图层 3
	this.instance_3 = new lib.ipop_1_22_84718();
	this.instance_3.setTransform(25.4,-78);

	this.addChild(this.instance_3,this.shape,this.instance_2,this.instance_1,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(25.4,-78,658.9,1476.2);


(lib.ipop_1_5_19742 = function() {
	this.initialize();

	// 图层 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(192,192,192,0.008)").s().p("AnzHzIAAvmIPmAAIAAPmg");
	this.shape.setTransform(50,50);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,100,100);


(lib.ipop_1_4_53577 = function() {
	this.initialize();

}).prototype = p = new cjs.Container();
p.nominalBounds = null;


(lib.ipop_1_2_72210 = function() {
	this.initialize();

	// 图层 1
	this.instance = new lib._02();
	this.instance.setTransform(0,0,1.15,1.15);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,1323,1795.8);


(lib.ipop_1_11_8666 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.ipop_1_12_20885();
	this.instance.setTransform(18.8,22.8,1,1,0,0,0,13.5,22.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:31.3},9).to({y:22.8},9).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.6,-128,42.8,82.5);


(lib.ipop_1_6_5452 = function() {
	this.initialize();

	// 图层 1
	this.instance = new lib.ipop_1_4_53577("synched",0);
	this.instance.setTransform(337,-236.9);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = null;


(lib.ipop_1_3_34216 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{xunhuan:18,ending:50});

	// timeline functions:
	this.frame_49 = function() {
		this.gotoAndPlay("xunhuan")
	}
	this.frame_60 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(49).call(this.frame_49).wait(11).call(this.frame_60).wait(1));

	// 提示
	this.instance = new lib.ipop_1_10_97962();
	this.instance.setTransform(193.9,665.7,1.15,1.15,0,0,0,78.1,24.4);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(7).to({_off:false},0).to({y:647.3,alpha:1},11,cjs.Ease.get(1)).wait(32).to({alpha:0},10).wait(1));

	// 箭头
	this.instance_1 = new lib.ipop_1_11_8666("synched",0);
	this.instance_1.setTransform(192.4,563.8,1.15,1.15,0,180,0,-2,-83.4);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({y:545.4,alpha:1,startPosition:11},11,cjs.Ease.get(1)).wait(39).to({startPosition:12},0).to({alpha:0},10).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(168.7,520.2,49.3,94.8);


(lib.ipop_1_1_3568 = function() {
	this.initialize();

	// 图层 1
	this.instance = new lib.ipop_1_9_52780("synched",0);
	this.instance.setTransform(368.1,522.8,1.15,1.15,0,0,0,119,13);

	this.instance_1 = new lib.ipop_1_15_63360();
	this.instance_1.setTransform(0,0,1.15,1.15);

	this.addChild(this.instance_1,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,1323,1795.8);


(lib.ipop_1_13_17377 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// 图层 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(214,214,214,0.008)").s().p("Ele4HzzMAAAvnlMK9xAAAMAAAPnlg");
	this.shape.setTransform(428.6,32.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	// 图层 1
	this.instance = new lib.ipop_1_19_72026();
	this.instance.setTransform(-14.1,20.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(1));

	// 遮罩 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EghFAO4Qi3hWhkktQi8m3AwnbQA8jhDmhLQMLjKM9CVQFbBeAxEpQgSHej/GpQh6DIkjCQQlHBzkzAAQkcAAkLhjgAQ+OfQkiiQh6jIQkAmpgRneQAxkpFbheQM8iVMMDLQDmBLA7DhQAwHbi7G3QhkEti4BVQkKBkkdAAQkyAAlIh0g");
	mask.setTransform(270.5,105.2);

	// 01
	this.mybg = new lib.ipop_1_1_3568();
	this.mybg.setTransform(370,-60.6,1,1,0,0,0,661.5,897.9);

	this.mybg.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.mybg).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1817.1,-3166.1,4491.5,6397.5);


(lib.ipop_1_7_54552 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"ending":97});

	// timeline functions:
	this.frame_0 = function() {
		var that=this
		var oldy=0
		var oldx=0
		var olddragy=0
		var olddragx=0
		var oldbgy=0
		var oldbgx=0
		
		var x1min=that.myclickbtn1.x	
		var x1max=that.myclickbtn1.x+that.myclickbtn1.scaleX*100	
		var y1min=that.myclickbtn1.y	
		var y1max=that.myclickbtn1.y+that.myclickbtn1.scaleY*100
		var x2min=that.myclickbtn2.x	
		var x2max=that.myclickbtn2.x+that.myclickbtn2.scaleX*100	
		var y2min=that.myclickbtn2.y	
		var y2max=that.myclickbtn2.y+that.myclickbtn2.scaleY*100	
		var x3min=that.myclickbtn3.x	
		var x3max=that.myclickbtn3.x+that.myclickbtn3.scaleX*100	
		var y3min=that.myclickbtn3.y	
		var y3max=that.myclickbtn3.y+that.myclickbtn3.scaleY*100
		
		function myc1(e){
		var localpoint=new createjs.Point(e.stageX,e.stageY)	
		localpoint=that.globalToLocal(localpoint.x,localpoint.y)
		oldx=localpoint.x	
		oldy=localpoint.y
		if(that.dragbtn.currentFrame==0){	
		olddragx=that.dragbtn.x
		olddragy=that.dragbtn.y
		oldbgx=that.dragbtn.mybg.x
		oldbgy=that.dragbtn.mybg.y
		}
		stage.addEventListener("pressmove",mypressm)
		stage.addEventListener("pressup",mypressu)
		if(stage.mynote.currentFrame<=49&&that.dragbtn.currentFrame==0){
		var impimg=new Image()
		impimg.src=stage.clickimp[stage.currentcitynum]
		document.body.appendChild(impimg)
		try{
		mraid.extend.cancelSplashAdCountdown()
		}catch(e){
		} 	
		stage.mynote.gotoAndPlay("ending")
		}
		stage.clickflag=true	
		}
		function mypressm(e){
		var localpoint=new createjs.Point(e.stageX,e.stageY)	
		localpoint=that.globalToLocal(localpoint.x,localpoint.y)
		var deltx=(localpoint.x-oldx)
		var delty=(localpoint.y-oldy)
		if(that.dragbtn.currentFrame==0){
		that.dragbtn.x=deltx+olddragx
		that.dragbtn.y=delty+olddragy
		that.dragbtn.mybg.x=oldbgx-deltx	
		that.dragbtn.mybg.y=oldbgy-delty
		}
		}
		function mypressu(e){
		var localpoint=new createjs.Point(e.stageX,e.stageY)	
		localpoint=that.globalToLocal(localpoint.x,localpoint.y)
		oldx=localpoint.x
		oldy=localpoint.y	
		if(that.dragbtn.currentFrame==1){
		if(oldx>x1min&&oldx<x1max&&oldy>y1min&&oldy<y1max){
		console.log(stage.click1[stage.currentcitynum])
		mraid.extend.viewMore(stage.click1[stage.currentcitynum])
		}else if(oldx>x2min&&oldx<x2max&&oldy>y2min&&oldy<y2max){
		console.log(stage.click2[stage.currentcitynum])
		mraid.extend.viewMore(stage.click2[stage.currentcitynum])
		}else if(oldx>x3min&&oldx<x3max&&oldy>y3min&&oldy<y3max){
		console.log(stage.click3[stage.currentcitynum])
		mraid.extend.viewMore(stage.click3[stage.currentcitynum])
		}	
		return	
		}	
		stage.removeEventListener("pressmove",mypressm)
		stage.removeEventListener("pressup",mypressu)
		}
		that.dragbtn.addEventListener("mousedown",myc1)
		stage.mynote=this.mynote
	}
	this.frame_49 = function() {
		if(stage.clickflag==false){
		this.gotoAndPlay("ending")	
		}
	}
	this.frame_97 = function() {
		this.dragbtn.gotoAndStop(1)
	}
	this.frame_193 = function() {
		this.stop()
		try {
		mraid.extend.skipAd()
		} catch (e) {
			
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(49).call(this.frame_49).wait(48).call(this.frame_97).wait(96).call(this.frame_193).wait(1));

	// 眼镜
	this.dragbtn = new lib.ipop_1_13_17377();
	this.dragbtn.setTransform(182.3,488.7,1,1,0,0,0,291.9,98.4);

	this.timeline.addTween(cjs.Tween.get(this.dragbtn).wait(194));

	// fwfg
	this.myclickbtn3 = new lib.ipop_1_5_19742();
	this.myclickbtn3.setTransform(-186,620.5,7.515,6.804);

	this.myclickbtn2 = new lib.ipop_1_5_19742();
	this.myclickbtn2.setTransform(-186,194.6,7.515,4.077);

	this.myclickbtn1 = new lib.ipop_1_5_19742();
	this.myclickbtn1.setTransform(-186,-290.6,7.539,4.684);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.myclickbtn1},{t:this.myclickbtn2},{t:this.myclickbtn3}]},97).wait(97));

	// 定帧
	this.instance = new lib.ipop_1_8_24192();
	this.instance.setTransform(190,405.8,1.575,1.575,0,0,0,351.9,528.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(97).to({_off:false},0).to({regX:352,scaleX:1.15,scaleY:1.15,x:190.2,alpha:1},12,cjs.Ease.get(0.8)).wait(85));

	// 图层 2
	this.mynote = new lib.ipop_1_3_34216();
	this.mynote.setTransform(36.5,95.6,1,1,0,0,0,60.1,69);

	this.timeline.addTween(cjs.Tween.get(this.mynote).wait(194));

	// logo
	this.instance_1 = new lib.ipop_1_9_52780("synched",0);
	this.instance_1.setTransform(-33.3,-45.3,1.15,1.15,0,0,0,119,13);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},97).wait(97));

	// 02
	this.instance_2 = new lib.ipop_1_2_72210();
	this.instance_2.setTransform(260.3,329.2,1,1,0,0,0,661.5,897.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(194));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1926.8,-2775.8,4491.5,6397.6);


// stage content:
(lib.index1 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		createjs.Touch.enable(stage,false,false);
		var that=this
		var oldy=that.movie.y
		function abc(){
		if(window.innerHeight/window.innerWidth<782/414){
		
		return
		}	
		if(window.innerHeight/window.innerWidth>2.1652){
		that.movie.y=90+oldy
		return
		}
		}
		setTimeout(abc,200)
		stage.clickflag=false
		var cityarray=[{cityname:"北京" ,cityid:0},{cityname:"上海",cityid:1},{cityname:"广州",cityid:2},{cityname:"成都",cityid:3},{cityname:"昆明",cityid:4},{cityname:"郑州",cityid:5},{cityname:"杭州",cityid:6}]
		console.log(stage.city)
		stage.currentcitynum=-1
		for(var item in cityarray){
		if(cityarray[item].cityname==stage.city){
		stage.currentcitynum=cityarray[item].cityid	
		break;
		}	
		}
		stage.clickimp=new Array()
		stage.click1=new Array()
		stage.click2=new Array()
		stage.click3=new Array()
		
		stage.clickimp.push("http://tytx.m.cn.miaozhen.com/r/k=2076855&p=7ENQ4&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=")
		stage.clickimp.push("http://tytx.m.cn.miaozhen.com/r/k=2076855&p=7ENQ5&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=")
		stage.clickimp.push("http://tytx.m.cn.miaozhen.com/r/k=2076855&p=7ENQ6&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=")
		stage.clickimp.push("http://tytx.m.cn.miaozhen.com/r/k=2076855&p=7ENQ7&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=")
		stage.clickimp.push("http://tytx.m.cn.miaozhen.com/r/k=2076855&p=7ENQ8&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=")
		stage.clickimp.push("http://tytx.m.cn.miaozhen.com/r/k=2076855&p=7ENQ9&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=")
		stage.clickimp.push("http://tytx.m.cn.miaozhen.com/r/k=2076855&p=7ENQA&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=")
		
		stage.click1.push("http://tytx.m.cn.miaozhen.com/r/k=2077986&p=7EOb3&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&ro=sm&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=http://wxdemo.essilorchina.com/Eyezen2018/Home/Baodao")
		stage.click1.push("http://tytx.m.cn.miaozhen.com/r/k=2077986&p=7EOb4&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&ro=sm&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=http://wxdemo.essilorchina.com/Eyezen2018/Home/Baodao")
		stage.click1.push("http://tytx.m.cn.miaozhen.com/r/k=2077986&p=7EOb5&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&ro=sm&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=http://wxdemo.essilorchina.com/Eyezen2018/Home/Baodao")
		stage.click1.push("http://tytx.m.cn.miaozhen.com/r/k=2077986&p=7EOb6&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&ro=sm&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=http://wxdemo.essilorchina.com/Eyezen2018/Home/Baodao")
		stage.click1.push("http://tytx.m.cn.miaozhen.com/r/k=2077986&p=7EOb7&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&ro=sm&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=http://wxdemo.essilorchina.com/Eyezen2018/Home/Baodao")
		stage.click1.push("http://tytx.m.cn.miaozhen.com/r/k=2077986&p=7EOb8&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&ro=sm&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=http://wxdemo.essilorchina.com/Eyezen2018/Home/Baodao")
		stage.click1.push("http://tytx.m.cn.miaozhen.com/r/k=2077986&p=7EOb9&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&ro=sm&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=http://wxdemo.essilorchina.com/Eyezen2018/Home/Baodao")
		
		stage.click2.push("http://tytx.m.cn.miaozhen.com/r/k=2077986&p=7EObc&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&ro=sm&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=https://item.jd.com/26814453759.html")
		stage.click2.push("http://tytx.m.cn.miaozhen.com/r/k=2077986&p=7EObd&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&ro=sm&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=https://item.jd.com/26814453759.html")
		stage.click2.push("http://tytx.m.cn.miaozhen.com/r/k=2077986&p=7EObe&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&ro=sm&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=https://item.jd.com/26814453759.html")
		stage.click2.push("http://tytx.m.cn.miaozhen.com/r/k=2077986&p=7EObf&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&ro=sm&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=https://item.jd.com/26814453759.html")
		stage.click2.push("http://tytx.m.cn.miaozhen.com/r/k=2077986&p=7EObg&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&ro=sm&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=https://item.jd.com/26814453759.html")
		stage.click2.push("http://tytx.m.cn.miaozhen.com/r/k=2077986&p=7EObh&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&ro=sm&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=https://item.jd.com/26814453759.html")
		stage.click2.push("http://tytx.m.cn.miaozhen.com/r/k=2077986&p=7EObi&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&ro=sm&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=https://item.jd.com/26814453759.html")
		
		stage.click3.push("http://tytx.m.cn.miaozhen.com/r/k=2077986&p=7EOcB&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&ro=sm&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=http://wxdemo.essilorchina.com/Eyezen2018/Home/Essilor")
		stage.click3.push("http://tytx.m.cn.miaozhen.com/r/k=2077986&p=7EOcC&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&ro=sm&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=http://wxdemo.essilorchina.com/Eyezen2018/Home/Essilor")
		stage.click3.push("http://tytx.m.cn.miaozhen.com/r/k=2077986&p=7EOcD&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&ro=sm&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=http://wxdemo.essilorchina.com/Eyezen2018/Home/Essilor")
		stage.click3.push("http://tytx.m.cn.miaozhen.com/r/k=2077986&p=7EOcE&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&ro=sm&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=http://wxdemo.essilorchina.com/Eyezen2018/Home/Essilor")
		stage.click3.push("http://tytx.m.cn.miaozhen.com/r/k=2077986&p=7EOcF&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&ro=sm&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=http://wxdemo.essilorchina.com/Eyezen2018/Home/Essilor")
		stage.click3.push("http://tytx.m.cn.miaozhen.com/r/k=2077986&p=7EOcG&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&ro=sm&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=http://wxdemo.essilorchina.com/Eyezen2018/Home/Essilor")
		stage.click3.push("http://tytx.m.cn.miaozhen.com/r/k=2077986&p=7EOcH&dx=__IPDX__&rt=2&ns=__IP__&ni=__IESID__&v=__LOC__&xa=__ADPLATFORM__&tr=__REQUESTID__&ro=sm&mo=__OS__&m0=__OPENUDID__&m0a=__DUID__&m1=__ANDROIDID1__&m1a=__ANDROIDID__&m2=__IMEI__&m4=__AAID__&m5=__IDFA__&m6=__MAC1__&m6a=__MAC__&txp=__TXP__&o=http://wxdemo.essilorchina.com/Eyezen2018/Home/Essilor")
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// 图层 1
	this.instance = new lib.ipop_1_6_5452("synched",0);
	this.instance.setTransform(-289,420.1,1,1,0,0,0,239.8,-230.8);

	this.movie = new lib.ipop_1_7_54552();
	this.movie.setTransform(114.6,134.9,0.56,0.56,0,0,0,28.8,63.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.movie},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-773.5,-1006.7,2515.3,3582.6);

})(lib = lib||{}, images = images||{}, createjs = createjs||{});
var lib, images, createjs;